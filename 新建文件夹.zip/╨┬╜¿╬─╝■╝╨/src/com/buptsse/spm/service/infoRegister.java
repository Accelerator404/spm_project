package com.buptsse.spm.service;

public interface infoRegister {
	public boolean uploadPortriat();

}
